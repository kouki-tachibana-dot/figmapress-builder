<?php
/** Authenticated REST endpoints used by FigmaPress Builder. */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Restore Application Password authentication on hosts that strip the
 * standard Authorization header before PHP. FigmaPress retries with this
 * connector-specific header only after normal HTTP Basic auth returns 401.
 */
function figmapress_connector_restore_application_password_header( $user_id ) {
    if ( $user_id || ! empty( $_SERVER['PHP_AUTH_USER'] ) || ! empty( $_SERVER['PHP_AUTH_PW'] ) ) {
        return $user_id;
    }

    $authorization = isset( $_SERVER['HTTP_X_FIGMAPRESS_AUTHORIZATION'] )
        ? trim( wp_unslash( $_SERVER['HTTP_X_FIGMAPRESS_AUTHORIZATION'] ) )
        : '';
    if ( 0 !== stripos( $authorization, 'Basic ' ) ) {
        return $user_id;
    }

    $decoded = base64_decode( substr( $authorization, 6 ), true );
    if ( false === $decoded || false === strpos( $decoded, ':' ) ) {
        return $user_id;
    }

    list( $username, $password ) = explode( ':', $decoded, 2 );
    if ( '' === $username || '' === $password ) {
        return $user_id;
    }

    $_SERVER['PHP_AUTH_USER'] = $username;
    $_SERVER['PHP_AUTH_PW']   = $password;
    return $user_id;
}
add_filter( 'determine_current_user', 'figmapress_connector_restore_application_password_header', 19 );

function figmapress_connector_allow_auth_fallback_cors_header( $headers ) {
    $headers[] = 'X-FigmaPress-Authorization';
    return array_values( array_unique( $headers ) );
}
add_filter( 'rest_allowed_cors_headers', 'figmapress_connector_allow_auth_fallback_cors_header' );

function figmapress_connector_register_rest_routes() {
    register_rest_route(
        'figmapress/v1',
        '/status',
        array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => 'figmapress_connector_rest_status',
            'permission_callback' => 'figmapress_connector_rest_is_authenticated',
        )
    );
    register_rest_route(
        'figmapress/v1',
        '/auth-diagnostics',
        array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => 'figmapress_connector_rest_auth_diagnostics',
            'permission_callback' => '__return_true',
        )
    );
    register_rest_route(
        'figmapress/v1',
        '/gutenberg/pages',
        array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => 'figmapress_connector_rest_create_gutenberg_page',
            'permission_callback' => 'figmapress_connector_rest_can_edit_pages',
        )
    );
    register_rest_route(
        'figmapress/v1',
        '/elementor/pages',
        array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => 'figmapress_connector_rest_create_elementor_page',
            'permission_callback' => 'figmapress_connector_rest_can_edit_pages',
        )
    );
    register_rest_route(
        'figmapress/v1',
        '/elementor/uploads/(?P<upload>[a-f0-9-]{16,64})',
        array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => 'figmapress_connector_rest_upload_elementor_page',
            'permission_callback' => 'figmapress_connector_rest_can_edit_pages',
        )
    );
    register_rest_route(
        'figmapress/v1',
        '/elementor/pages/(?P<id>\d+)/snapshot',
        array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => 'figmapress_connector_rest_elementor_snapshot',
            'permission_callback' => 'figmapress_connector_rest_can_edit_requested_page',
        )
    );
    register_rest_route(
        'figmapress/v1',
        '/elementor/pages/(?P<id>\d+)/document',
        array(
            'methods'             => WP_REST_Server::EDITABLE,
            'callback'            => 'figmapress_connector_rest_update_elementor_document',
            'permission_callback' => 'figmapress_connector_rest_can_edit_requested_page',
        )
    );
    register_rest_route(
        'figmapress/v1',
        '/elementor/pages/(?P<id>\d+)/media',
        array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => 'figmapress_connector_rest_localize_elementor_media',
            'permission_callback' => 'figmapress_connector_rest_can_edit_requested_page',
        )
    );
}
add_action( 'rest_api_init', 'figmapress_connector_register_rest_routes' );

/**
 * Remember whether WordPress attempted Application Password authentication.
 * Only booleans are exposed by the diagnostic route; credentials and errors
 * are never returned or persisted.
 */
function figmapress_connector_record_application_password_failure() {
    $GLOBALS['figmapress_application_password_failed'] = true;
}
add_action( 'application_password_failed_authentication', 'figmapress_connector_record_application_password_failure' );

function figmapress_connector_record_application_password_success() {
    $GLOBALS['figmapress_application_password_succeeded'] = true;
}
add_action( 'application_password_did_authenticate', 'figmapress_connector_record_application_password_success' );

/**
 * The diagnostic endpoint is public and intentionally returns booleans only.
 * Let it run even when WordPress has already recorded a failed Application
 * Password attempt, otherwise core short-circuits the request with HTTP 401
 * before the route callback can report whether the header reached PHP.
 */
function figmapress_connector_allow_auth_diagnostics( $result ) {
    $request_uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    $rest_route  = isset( $_GET['rest_route'] ) ? wp_unslash( $_GET['rest_route'] ) : '';

    if (
        false !== strpos( $request_uri, '/wp-json/figmapress/v1/auth-diagnostics' ) ||
        '/figmapress/v1/auth-diagnostics' === $rest_route
    ) {
        return null;
    }

    return $result;
}
add_filter( 'rest_authentication_errors', 'figmapress_connector_allow_auth_diagnostics', PHP_INT_MAX );

function figmapress_connector_rest_auth_diagnostics( WP_REST_Request $request ) {
    $authorization = $request->get_header( 'authorization' );
    $fallback_authorization = $request->get_header( 'x_figmapress_authorization' );

    return rest_ensure_response(
        array(
            'connectorVersion'             => FIGMAPRESS_CONNECTOR_VERSION,
            'authorizationHeaderSeen'      => is_string( $authorization ) && '' !== trim( $authorization ),
            'basicAuthorizationSeen'       => is_string( $authorization ) && 0 === stripos( trim( $authorization ), 'Basic ' ),
            'httpAuthorizationServerVar'   => ! empty( $_SERVER['HTTP_AUTHORIZATION'] ),
            'redirectAuthorizationServerVar' => ! empty( $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ),
            'fallbackAuthorizationHeaderSeen' => is_string( $fallback_authorization ) && '' !== trim( $fallback_authorization ),
            'phpAuthUserSeen'              => ! empty( $_SERVER['PHP_AUTH_USER'] ),
            'phpAuthPasswordSeen'          => ! empty( $_SERVER['PHP_AUTH_PW'] ),
            'applicationPasswordFailed'    => ! empty( $GLOBALS['figmapress_application_password_failed'] ),
            'applicationPasswordSucceeded' => ! empty( $GLOBALS['figmapress_application_password_succeeded'] ),
        )
    );
}

function figmapress_connector_rest_can_edit_pages() {
    return current_user_can( 'edit_pages' );
}

function figmapress_connector_rest_can_edit_requested_page( WP_REST_Request $request ) {
    $post_id = absint( $request->get_param( 'id' ) );
    return $post_id > 0 && current_user_can( 'edit_post', $post_id );
}

function figmapress_connector_rest_is_authenticated() {
    if ( is_user_logged_in() ) {
        return true;
    }
    return new WP_Error( 'figmapress_auth_required', 'Authentication is required.', array( 'status' => 401 ) );
}

function figmapress_connector_rest_status() {
    global $wp_version;
    $current_user = wp_get_current_user();
    figmapress_connector_load_elementor_widget_classes();
    return rest_ensure_response(
        array(
            'connectorVersion' => FIGMAPRESS_CONNECTOR_VERSION,
            'wordpressVersion' => $wp_version,
            'canEditPages'      => current_user_can( 'edit_pages' ),
            'user'              => array(
                'id'   => absint( $current_user->ID ),
                'name' => $current_user->display_name
                    ? $current_user->display_name
                    : $current_user->user_login,
            ),
            'pairing'           => array(
                'supported' => true,
                'active'    => ! empty( $GLOBALS['figmapress_pairing_authenticated'] ),
            ),
            'elementor'         => array(
                'active'  => did_action( 'elementor/loaded' ) > 0 || defined( 'ELEMENTOR_VERSION' ),
                'version' => defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : null,
            ),
            'functionalWidgets' => array(
                'navigation'  => class_exists( 'FigmaPress_Nav_Widget' ),
                'links'       => class_exists( 'FigmaPress_Link_Widget' ),
                'carousel'    => class_exists( 'FigmaPress_Carousel_Widget' ),
                'contactForm' => class_exists( 'FigmaPress_Contact_Form_Widget' ),
                'accordion'   => class_exists( 'FigmaPress_Accordion_Widget' ),
            ),
            'visualQa'          => array(
                'snapshot'       => true,
                'documentUpdate' => true,
                'revisions'      => true,
                'webfonts'       => true,
                'gradients'      => true,
                'effects'        => true,
                'imageTransforms' => true,
                'mediaPersistence' => true,
            ),
        )
    );
}

function figmapress_connector_rest_create_gutenberg_page( WP_REST_Request $request ) {
    $params  = $request->get_json_params();
    $title   = isset( $params['title'] )
        ? sanitize_text_field( $params['title'] )
        : '';
    $slug    = isset( $params['slug'] )
        ? sanitize_title( $params['slug'] )
        : '';
    $content = isset( $params['content'] ) && is_string( $params['content'] )
        ? wp_kses_post( $params['content'] )
        : '';
    if ( '' === $title || '' === $content ) {
        return new WP_Error(
            'figmapress_invalid_gutenberg_page',
            'The Gutenberg page payload is invalid.',
            array( 'status' => 422 )
        );
    }

    $post_id = wp_insert_post(
        array(
            'post_type'    => 'page',
            'post_status'  => 'draft',
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
        ),
        true
    );
    if ( is_wp_error( $post_id ) ) {
        return $post_id;
    }
    return rest_ensure_response(
        array(
            'id'          => $post_id,
            'slug'        => get_post_field( 'post_name', $post_id ),
            'status'      => 'draft',
            'target'      => 'gutenberg',
            'editLink'    => admin_url( 'post.php?post=' . $post_id . '&action=edit' ),
            'previewLink' => get_preview_post_link( $post_id ),
            'rawLink'     => get_permalink( $post_id ),
        )
    );
}

function figmapress_connector_find_page_by_meta( $meta_key, $meta_value ) {
    if ( '' === $meta_value ) {
        return 0;
    }
    $pages = get_posts(
        array(
            'post_type'              => 'page',
            'post_status'            => array( 'draft', 'pending', 'private', 'publish', 'future' ),
            'posts_per_page'         => 1,
            'fields'                 => 'ids',
            'meta_key'               => $meta_key,
            'meta_value'             => $meta_value,
            'no_found_rows'          => true,
            'orderby'                => 'ID',
            'order'                  => 'DESC',
            'suppress_filters'       => false,
            'update_post_meta_cache' => false,
            'update_post_term_cache' => false,
        )
    );
    return isset( $pages[0] ) ? absint( $pages[0] ) : 0;
}

/**
 * Release only the lock created by the current request, including when PHP is
 * terminated by a host timeout while Elementor is storing a large document.
 */
function figmapress_connector_register_request_lock_cleanup( $lock_key, $lock_token ) {
    register_shutdown_function(
        static function () use ( $lock_key, $lock_token ) {
            $current = get_option( $lock_key );
            if (
                is_array( $current ) && isset( $current['token'] ) &&
                is_string( $current['token'] ) && hash_equals( $lock_token, $current['token'] )
            ) {
                delete_option( $lock_key );
            }
        }
    );
}

function figmapress_connector_request_lock_is_stale( $started ) {
    // Normal document persistence completes in seconds. A two-minute lock is
    // enough to serialize writes while allowing a disconnected browser to
    // recover without waiting for the previous ten-minute safety window.
    return $started && $started < time() - ( 2 * MINUTE_IN_SECONDS );
}

/**
 * Receive a large Elementor page in bounded browser requests, then forward the
 * reconstructed JSON to the normal creation handler. Upload state is scoped to
 * the authenticated user and expires automatically.
 */
function figmapress_connector_rest_upload_elementor_page( WP_REST_Request $request ) {
    $upload_id = sanitize_text_field( $request->get_param( 'upload' ) );
    $params    = $request->get_json_params();
    if ( ! is_array( $params ) ) {
        $params = $request->get_body_params();
    }
    $index     = isset( $params['index'] ) ? absint( $params['index'] ) : -1;
    $total     = isset( $params['total'] ) ? absint( $params['total'] ) : 0;
    $chunk     = isset( $params['chunk'] ) && is_string( $params['chunk'] ) ? $params['chunk'] : '';
    if (
        ! preg_match( '/^[a-f0-9-]{16,64}$/i', $upload_id ) ||
        $total < 1 || $total > 128 || $index < 0 || $index >= $total ||
        '' === $chunk || strlen( $chunk ) > 128000 ||
        ! preg_match( '/^[A-Za-z0-9+\/=]+$/', $chunk )
    ) {
        return new WP_Error( 'figmapress_invalid_upload_chunk', 'Elementor分割データが無効です。', array( 'status' => 422 ) );
    }

    $decoded = base64_decode( $chunk, true );
    if ( false === $decoded || strlen( $decoded ) > 72000 ) {
        return new WP_Error( 'figmapress_invalid_upload_chunk', 'Elementor分割データが無効です。', array( 'status' => 422 ) );
    }

    $upload_key = 'figmapress_upload_' . get_current_user_id() . '_' . substr(
        hash_hmac( 'sha256', $upload_id, wp_salt( 'nonce' ) ),
        0,
        24
    );
    $state = get_transient( $upload_key );
    if ( ! is_array( $state ) || ! isset( $state['total'], $state['chunks'] ) || absint( $state['total'] ) !== $total ) {
        $state = array( 'total' => $total, 'chunks' => array() );
    }
    $state['chunks'][ $index ] = $decoded;
    set_transient( $upload_key, $state, 15 * MINUTE_IN_SECONDS );

    if ( count( $state['chunks'] ) < $total ) {
        return rest_ensure_response(
            array(
                'complete' => false,
                'received' => count( $state['chunks'] ),
                'total'    => $total,
            )
        );
    }

    ksort( $state['chunks'], SORT_NUMERIC );
    for ( $expected = 0; $expected < $total; $expected++ ) {
        if ( ! array_key_exists( $expected, $state['chunks'] ) ) {
            return new WP_Error( 'figmapress_incomplete_upload', 'Elementor分割データが不足しています。', array( 'status' => 409 ) );
        }
    }
    $body = implode( '', $state['chunks'] );
    delete_transient( $upload_key );
    if ( strlen( $body ) > 4000000 || ! is_array( json_decode( $body, true ) ) ) {
        return new WP_Error( 'figmapress_invalid_upload', 'Elementorデータを再構成できませんでした。', array( 'status' => 422 ) );
    }

    $forward = new WP_REST_Request( 'POST', '/figmapress/v1/elementor/pages' );
    $forward->set_header( 'content-type', 'application/json' );
    $forward->set_body( $body );
    return figmapress_connector_rest_create_elementor_page( $forward );
}

function figmapress_connector_rest_create_elementor_page( WP_REST_Request $request ) {
    if ( ! did_action( 'elementor/loaded' ) && ! defined( 'ELEMENTOR_VERSION' ) ) {
        return new WP_Error( 'figmapress_elementor_missing', 'Elementor is not active on this site.', array( 'status' => 409 ) );
    }

    $container_activated = figmapress_connector_ensure_elementor_containers();
    if ( is_wp_error( $container_activated ) ) {
        return $container_activated;
    }

    $warnings = array();
    if ( $container_activated ) {
        $warnings[] = 'Elementorの安定機能「コンテナ」を有効化しました。既存ページの内容は変更していません。';
    }

    $params     = $request->get_json_params();
    $title      = isset( $params['title'] ) ? sanitize_text_field( $params['title'] ) : '';
    $slug       = isset( $params['slug'] ) ? sanitize_title( $params['slug'] ) : '';
    $request_id = isset( $params['requestId'] ) ? sanitize_text_field( $params['requestId'] ) : '';
    $source_key = isset( $params['sourceKey'] ) ? sanitize_text_field( $params['sourceKey'] ) : '';
    $template   = isset( $params['template'] ) && is_array( $params['template'] ) ? $params['template'] : null;
    if ( '' === $title || ! $template || '0.4' !== ( isset( $template['version'] ) ? (string) $template['version'] : '' ) ) {
        return new WP_Error( 'figmapress_invalid_template', 'The Elementor template payload is invalid.', array( 'status' => 422 ) );
    }
    if ( '' !== $request_id && ! preg_match( '/^[a-f0-9-]{16,64}$/i', $request_id ) ) {
        return new WP_Error( 'figmapress_invalid_request_id', '作成リクエストの識別情報が無効です。', array( 'status' => 422 ) );
    }
    if ( '' !== $source_key && ! preg_match( '/^figma:[A-Za-z0-9_-]{6,160}:(?:root|[0-9]+:[0-9]+)$/', $source_key ) ) {
        return new WP_Error( 'figmapress_invalid_source_key', 'Figma変換元の識別情報が無効です。', array( 'status' => 422 ) );
    }

    $identity         = '' !== $source_key ? $source_key : $request_id;
    $request_lock_key = '' !== $identity
        ? 'figmapress_request_' . substr( hash_hmac( 'sha256', $identity, wp_salt( 'nonce' ) ), 0, 32 )
        : '';
    $existing_id      = '' !== $source_key
        ? figmapress_connector_find_page_by_meta( '_figmapress_source_key', $source_key )
        : 0;
    if ( ! $existing_id && '' !== $request_id ) {
        $existing_id = figmapress_connector_find_page_by_meta( '_figmapress_request_id', $request_id );
    }
    $reuse_existing = false;
    if ( $existing_id ) {
        if ( $existing_id && current_user_can( 'edit_post', $existing_id ) ) {
            $stored_elements = figmapress_connector_count_elementor_elements( figmapress_connector_read_elementor_data( $existing_id ) );
            $existing_lock   = get_option( $request_lock_key );
            $lock_started    = is_array( $existing_lock ) && isset( $existing_lock['started'] )
                ? absint( $existing_lock['started'] )
                : 0;
            if ( $lock_started && ! figmapress_connector_request_lock_is_stale( $lock_started ) ) {
                return new WP_Error(
                    'figmapress_request_in_progress',
                    '同じElementor下書きを作成中です。少し待ってから同じボタンを再度押してください。',
                    array( 'status' => 409, 'postId' => $existing_id )
                );
            }
            $existing_status = get_post_status( $existing_id );
            if ( 'draft' !== $existing_status ) {
                return new WP_Error(
                    'figmapress_request_already_completed',
                    'この処理で作成したページは、すでに下書き以外の状態になっています。',
                    array( 'status' => 409, 'postId' => $existing_id )
                );
            }
            if ( 0 === $stored_elements ) {
                wp_delete_post( $existing_id, true );
                delete_option( $request_lock_key );
                $existing_id = 0;
            } elseif ( '' === $source_key ) {
                return rest_ensure_response(
                    array(
                        'id'             => $existing_id,
                        'slug'           => get_post_field( 'post_name', $existing_id ),
                        'status'         => $existing_status,
                        'target'         => 'elementor',
                        'editLink'       => admin_url( 'post.php?post=' . $existing_id . '&action=elementor' ),
                        'previewLink'    => get_preview_post_link( $existing_id ),
                        'rawLink'        => get_permalink( $existing_id ),
                        'storedElements' => $stored_elements,
                        'idempotent'     => true,
                        'updated'        => false,
                        'warnings'       => array( '前回の処理で作成済みの下書きを再利用しました。重複ページは作成していません。' ),
                    )
                );
            } else {
                $reuse_existing = true;
            }
        }
    }

    $element_count = 0;
    $content       = figmapress_connector_sanitize_elementor_elements(
        isset( $template['content'] ) ? $template['content'] : array(),
        $element_count
    );
    if ( is_wp_error( $content ) ) {
        return $content;
    }
    if ( 0 === $element_count ) {
        return new WP_Error( 'figmapress_empty_template', 'The Elementor template contains no supported elements.', array( 'status' => 422 ) );
    }

    if ( '' !== $request_lock_key ) {
        $lock_token       = wp_generate_uuid4();
        $lock_value       = array(
            'started' => time(),
            'user'    => get_current_user_id(),
            'token'   => $lock_token,
        );
        $locked           = add_option( $request_lock_key, $lock_value, '', false );
        if ( ! $locked ) {
            $existing_lock = get_option( $request_lock_key );
            $started       = is_array( $existing_lock ) && isset( $existing_lock['started'] )
                ? absint( $existing_lock['started'] )
                : 0;
            if ( figmapress_connector_request_lock_is_stale( $started ) ) {
                delete_option( $request_lock_key );
                $locked = add_option( $request_lock_key, $lock_value, '', false );
            }
        }
        if ( ! $locked ) {
            return new WP_Error(
                'figmapress_request_in_progress',
                '同じElementor下書きを作成中です。少し待ってから同じボタンを再度押してください。',
                array( 'status' => 409 )
            );
        }
        figmapress_connector_register_request_lock_cleanup( $request_lock_key, $lock_token );
    }

    $page_template = isset( $params['pageTemplate'] ) ? $params['pageTemplate'] : 'elementor_canvas';
    if ( ! in_array( $page_template, array( 'elementor_canvas', 'elementor_header_footer', 'default' ), true ) ) {
        $page_template = 'elementor_canvas';
    }

    $created = ! $reuse_existing;
    if ( $reuse_existing ) {
        wp_save_post_revision( $existing_id );
        $post_id = wp_update_post(
            array(
                'ID'         => $existing_id,
                'post_title' => $title,
            ),
            true
        );
        $warnings[] = '同じFigmaファイル・ノードの既存下書きを更新しました。重複ページは作成していません。';
    } else {
        $post_id = wp_insert_post(
            array(
                'post_type'    => 'page',
                'post_status'  => 'draft',
                'post_title'   => $title,
                'post_name'    => $slug,
                'post_content' => '',
            ),
            true
        );
    }
    if ( is_wp_error( $post_id ) ) {
        if ( $request_lock_key ) {
            delete_option( $request_lock_key );
        }
        return $post_id;
    }
    if ( '' !== $request_id ) {
        update_post_meta( $post_id, '_figmapress_request_id', $request_id );
    }
    if ( '' !== $source_key ) {
        update_post_meta( $post_id, '_figmapress_source_key', $source_key );
    }
    $page_settings = isset( $template['page_settings'] ) && is_array( $template['page_settings'] )
        ? figmapress_connector_sanitize_elementor_value( $template['page_settings'] )
        : array();

    $media_total = figmapress_connector_count_unique_elementor_images( $content );
    update_post_meta( $post_id, '_figmapress_media_total', $media_total );
    delete_post_meta( $post_id, '_figmapress_media_failures' );
    $localized_images = figmapress_connector_load_media_map( $post_id );
    figmapress_connector_apply_elementor_image_map( $content, $localized_images );

    // Persist the complete editable document before any remote image work.
    // Hosts can terminate slow downloads; the page must never be left empty.
    $stored_elements = figmapress_connector_store_elementor_document( $post_id, $content, $page_settings, $page_template );
    if ( is_wp_error( $stored_elements ) ) {
        if ( $request_lock_key ) {
            delete_option( $request_lock_key );
        }
        if ( $created ) {
            wp_delete_post( $post_id, true );
        }
        return $stored_elements;
    }
    if ( $request_lock_key ) {
        delete_option( $request_lock_key );
    }

    // Return immediately after the editable document is durable. Remote image
    // downloads are resumed through the bounded /media endpoint. Keeping them
    // out of this request prevents shared hosts from terminating a large page
    // update before Elementor has cleared its CSS cache.
    $imported_media = 0;
    figmapress_connector_clear_elementor_cache( $post_id );
    $media_progress = figmapress_connector_elementor_media_progress( $content, $post_id );

    return rest_ensure_response(
        array_merge(
            array(
            'id'            => $post_id,
            'slug'          => get_post_field( 'post_name', $post_id ),
            'status'        => 'draft',
            'target'        => 'elementor',
            'editLink'      => admin_url( 'post.php?post=' . $post_id . '&action=elementor' ),
            'previewLink'   => get_preview_post_link( $post_id ),
            'rawLink'       => get_permalink( $post_id ),
            'importedMedia' => $imported_media,
            'storedElements' => $stored_elements,
            'idempotent'     => $reuse_existing,
            'updated'        => $reuse_existing,
            'warnings'      => $warnings,
            ),
            $media_progress
        )
    );
}

/**
 * Confirm that a mutation or snapshot request belongs to the FigmaPress draft
 * created by the current browser flow.
 */
function figmapress_connector_validate_owned_elementor_draft( WP_REST_Request $request ) {
    $post_id    = absint( $request->get_param( 'id' ) );
    $params     = $request->get_json_params();
    $request_id = isset( $params['requestId'] ) ? sanitize_text_field( $params['requestId'] ) : '';
    if ( $post_id <= 0 || 'page' !== get_post_type( $post_id ) || 'draft' !== get_post_status( $post_id ) ) {
        return new WP_Error( 'figmapress_draft_not_found', 'The requested Elementor draft is not available.', array( 'status' => 404 ) );
    }
    if ( '' === $request_id || ! preg_match( '/^[a-f0-9-]{16,64}$/i', $request_id ) ) {
        return new WP_Error( 'figmapress_invalid_request_id', '作成リクエストの識別情報が無効です。', array( 'status' => 422 ) );
    }

    $stored_request_id = (string) get_post_meta( $post_id, '_figmapress_request_id', true );
    if ( '' === $stored_request_id || ! hash_equals( $stored_request_id, $request_id ) ) {
        return new WP_Error( 'figmapress_draft_mismatch', 'この下書きは現在の変換処理では更新できません。', array( 'status' => 403 ) );
    }
    return $post_id;
}

/**
 * Import the next bounded media batch for an existing draft. Every completed
 * batch is persisted, so a browser timeout or reload can safely resume it.
 */
function figmapress_connector_rest_localize_elementor_media( WP_REST_Request $request ) {
    $post_id = figmapress_connector_validate_owned_elementor_draft( $request );
    if ( is_wp_error( $post_id ) ) {
        return $post_id;
    }

    $content = figmapress_connector_read_elementor_data( $post_id );
    if ( ! is_array( $content ) ) {
        return new WP_Error( 'figmapress_empty_template', 'The Elementor draft contains no editable document.', array( 'status' => 422 ) );
    }

    $warnings         = array();
    $imported_media   = 0;
    $media_deadline   = microtime( true ) + 24;
    $localized_images = figmapress_connector_load_media_map( $post_id );
    $media_failures   = figmapress_connector_load_media_failures( $post_id );
    $params           = $request->get_json_params();
    if ( ! empty( $params['retryFailed'] ) ) {
        $media_failures = array();
    }
    figmapress_connector_apply_elementor_image_map( $content, $localized_images );
    figmapress_connector_localize_elementor_images(
        $content,
        $post_id,
        $warnings,
        $imported_media,
        $media_deadline,
        $localized_images,
        $media_failures
    );
    figmapress_connector_save_media_map( $post_id, $localized_images );
    figmapress_connector_save_media_failures( $post_id, $media_failures );

    $page_settings = get_post_meta( $post_id, '_elementor_page_settings', true );
    if ( ! is_array( $page_settings ) ) {
        $page_settings = array();
    }
    $page_template = get_post_meta( $post_id, '_wp_page_template', true );
    if ( ! in_array( $page_template, array( 'elementor_canvas', 'elementor_header_footer', 'default' ), true ) ) {
        $page_template = 'elementor_canvas';
    }
    $stored = figmapress_connector_store_elementor_document( $post_id, $content, $page_settings, $page_template );
    if ( is_wp_error( $stored ) ) {
        return $stored;
    }
    figmapress_connector_clear_elementor_cache( $post_id );

    $progress = figmapress_connector_elementor_media_progress( $content, $post_id );
    if ( $progress['failedMedia'] > 0 ) {
        $warnings[] = '3回試行しても保存できない画像があります。元URLを保持して下書きは編集可能な状態にしています。';
    }
    return rest_ensure_response(
        array_merge(
            array(
                'postId'         => $post_id,
                'status'         => 'draft',
                'importedMedia'  => $imported_media,
                'storedElements' => $stored,
                'warnings'       => array_values( array_unique( $warnings ) ),
            ),
            $progress
        )
    );
}

function figmapress_connector_snapshot_upload_path( $url ) {
    $upload_dir  = wp_upload_dir();
    $upload_url  = isset( $upload_dir['baseurl'] ) ? trailingslashit( $upload_dir['baseurl'] ) : '';
    $upload_path = isset( $upload_dir['basedir'] ) ? trailingslashit( $upload_dir['basedir'] ) : '';
    $clean_url   = is_string( $url ) ? strtok( $url, '?#' ) : false;
    if ( ! $upload_url || ! $upload_path || ! is_string( $clean_url ) || 0 !== strpos( $clean_url, $upload_url ) ) {
        return null;
    }
    $relative_path = rawurldecode( substr( $clean_url, strlen( $upload_url ) ) );
    $candidate     = $upload_path . ltrim( $relative_path, '/' );
    $real_upload   = realpath( $upload_path );
    $real_candidate = realpath( $candidate );
    if (
        ! $real_upload
        || ! $real_candidate
        || 0 !== strpos( $real_candidate, trailingslashit( $real_upload ) )
        || ! is_readable( $real_candidate )
    ) {
        return null;
    }
    return $real_candidate;
}

/**
 * Convert a local Media Library image to a bounded data URL for html2canvas.
 * The data is returned only by the authenticated snapshot response and is not
 * written back to Elementor or exposed by the public draft URL.
 */
function figmapress_connector_snapshot_image_data_url( $url, &$total_bytes, &$asset_cache ) {
    $clean_url = esc_url_raw( html_entity_decode( $url, ENT_QUOTES, 'UTF-8' ), array( 'http', 'https' ) );
    if ( '' === $clean_url ) {
        return null;
    }
    if ( array_key_exists( $clean_url, $asset_cache ) ) {
        return is_string( $asset_cache[ $clean_url ] ) ? $asset_cache[ $clean_url ] : null;
    }
    if ( $total_bytes >= 24 * MB_IN_BYTES ) {
        $asset_cache[ $clean_url ] = null;
        return null;
    }
    $attachment_id = attachment_url_to_postid( $clean_url );
    if ( ! $attachment_id ) {
        // Elementor commonly renders an intermediate image size while
        // attachment_url_to_postid() can resolve only the original filename.
        $original_url = preg_replace(
            '/(?:-\d+x\d+|-scaled)(?=\.[A-Za-z0-9]{2,5}(?:$|[?#]))/',
            '',
            $clean_url
        );
        if ( is_string( $original_url ) && $original_url !== $clean_url ) {
            $attachment_id = attachment_url_to_postid( $original_url );
        }
    }
    if ( ! $attachment_id ) {
        $asset_cache[ $clean_url ] = null;
        return null;
    }
    $path = figmapress_connector_snapshot_upload_path( $clean_url );
    if ( ! $path ) {
        $path = get_attached_file( $attachment_id );
    }

    // The comparison captures at most 800px wide. Prefer WordPress's
    // generated 768px asset when it is smaller than the source so all images
    // fit in one authenticated snapshot without materially reducing accuracy.
    $preview = wp_get_attachment_image_src( $attachment_id, 'medium_large' );
    if ( is_array( $preview ) && ! empty( $preview[0] ) ) {
        $preview_path = figmapress_connector_snapshot_upload_path( $preview[0] );
        $source_size  = is_string( $path ) && is_readable( $path ) ? filesize( $path ) : false;
        $preview_size = $preview_path ? filesize( $preview_path ) : false;
        if ( false !== $preview_size && $preview_size > 0 && ( false === $source_size || $preview_size < $source_size ) ) {
            $path = $preview_path;
        }
    }
    if ( ! is_string( $path ) || ! is_readable( $path ) ) {
        $asset_cache[ $clean_url ] = null;
        return null;
    }
    $size = filesize( $path );
    if ( false === $size || $size <= 0 || $size > 4 * MB_IN_BYTES || $total_bytes + $size > 24 * MB_IN_BYTES ) {
        $asset_cache[ $clean_url ] = null;
        return null;
    }
    $mime = wp_check_filetype( $path );
    $type = isset( $mime['type'] ) ? $mime['type'] : '';
    if ( ! in_array( $type, array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif', 'image/avif' ), true ) ) {
        $asset_cache[ $clean_url ] = null;
        return null;
    }
    $contents = file_get_contents( $path );
    if ( false === $contents ) {
        $asset_cache[ $clean_url ] = null;
        return null;
    }
    $total_bytes += $size;
    $asset_cache[ $clean_url ] = 'data:' . $type . ';base64,' . base64_encode( $contents );
    return $asset_cache[ $clean_url ];
}

function figmapress_connector_embed_snapshot_html_images( $html, &$total_bytes, &$asset_cache ) {
    return preg_replace_callback(
        '#(<img\b[^>]*\bsrc=["\'])(https?://[^"\']+)(["\'])#i',
        function ( $matches ) use ( &$total_bytes, &$asset_cache ) {
            $data_url = figmapress_connector_snapshot_image_data_url( $matches[2], $total_bytes, $asset_cache );
            return $data_url ? $matches[1] . $data_url . $matches[3] : $matches[0];
        },
        $html
    );
}

function figmapress_connector_embed_snapshot_css_images( $css, &$total_bytes, &$asset_cache ) {
    return preg_replace_callback(
        '#url\((["\']?)(https?://[^"\')]+)\1\)#i',
        function ( $matches ) use ( &$total_bytes, &$asset_cache ) {
            $data_url = figmapress_connector_snapshot_image_data_url( $matches[2], $total_bytes, $asset_cache );
            return $data_url ? 'url("' . $data_url . '")' : $matches[0];
        },
        $css
    );
}

/**
 * Return Elementor's active frontend foundation CSS for an isolated snapshot.
 * REST rendering does not run the complete theme enqueue lifecycle on every
 * host, so wp_print_styles() can omit the .e-con rules that apply container
 * height, positioning and flex layout variables.
 */
function figmapress_connector_snapshot_elementor_frontend_css() {
    $candidates = array();
    if ( defined( 'ELEMENTOR_ASSETS_PATH' ) ) {
        $candidates[] = trailingslashit( ELEMENTOR_ASSETS_PATH ) . 'css/frontend.min.css';
    }
    if ( defined( 'ELEMENTOR_PATH' ) ) {
        $candidates[] = trailingslashit( ELEMENTOR_PATH ) . 'assets/css/frontend.min.css';
    }

    foreach ( array_unique( $candidates ) as $path ) {
        if ( ! is_string( $path ) || ! is_readable( $path ) ) {
            continue;
        }
        $size = filesize( $path );
        if ( false === $size || $size <= 0 || $size > 1500000 ) {
            continue;
        }
        $css = file_get_contents( $path );
        if ( is_string( $css ) && '' !== trim( $css ) ) {
            return $css;
        }
    }
    return '';
}

/**
 * Read the Connector widget stylesheet for authenticated snapshot parity.
 *
 * REST requests do not always run the normal wp_enqueue_scripts lifecycle.
 * Relying only on an enqueued handle can therefore leave functional widgets
 * unstyled in Visual QA even though the public Elementor page is correct.
 */
function figmapress_connector_snapshot_interactions_css() {
    $path = FIGMAPRESS_CONNECTOR_DIR . 'assets/elementor-interactions.css';
    if ( ! is_readable( $path ) ) {
        return '';
    }
    $size = filesize( $path );
    if ( false === $size || $size <= 0 || $size > 100000 ) {
        return '';
    }
    $css = file_get_contents( $path );
    return is_string( $css ) ? figmapress_connector_snapshot_css_compatibility( $css ) : '';
}

/**
 * Keep snapshot CSS compatible with html2canvas while preserving the public
 * stylesheet's progressive color-mix() declarations. Every affected rule has
 * an rgba fallback immediately before the modern declaration.
 */
function figmapress_connector_snapshot_css_compatibility( $css ) {
    $compatible = preg_replace(
        '/^[\t ]*(?:outline|background|border-bottom):[^;\r\n]*color-mix\([^;\r\n]*;[\t ]*$/mi',
        '',
        (string) $css
    );
    return is_string( $compatible ) ? $compatible : '';
}

/**
 * Render the stored Elementor document through Elementor's real frontend
 * renderer. The response is authenticated and never exposes the draft publicly.
 */
function figmapress_connector_rest_elementor_snapshot( WP_REST_Request $request ) {
    $post_id = figmapress_connector_validate_owned_elementor_draft( $request );
    if ( is_wp_error( $post_id ) ) {
        return $post_id;
    }
    if ( ! class_exists( '\\Elementor\\Plugin' ) || ! isset( \Elementor\Plugin::$instance->frontend ) ) {
        return new WP_Error( 'figmapress_elementor_missing', 'Elementor is not active on this site.', array( 'status' => 409 ) );
    }

    try {
        $frontend = \Elementor\Plugin::$instance->frontend;
        // The REST lifecycle can skip the hooks that normally register these
        // assets. Register them explicitly before Elementor resolves widget
        // style dependencies and before wp_print_styles() runs.
        figmapress_connector_register_elementor_assets();
        if ( method_exists( $frontend, 'enqueue_styles' ) ) {
            $frontend->enqueue_styles();
        }
        wp_enqueue_style( 'elementor-frontend' );
        wp_enqueue_style( 'figmapress-elementor-interactions' );
        figmapress_connector_enqueue_page_webfonts( $post_id );

        if ( class_exists( '\\Elementor\\Core\\Files\\CSS\\Post' ) ) {
            $post_css = new \Elementor\Core\Files\CSS\Post( $post_id );
            if ( method_exists( $post_css, 'update' ) ) {
                $post_css->update();
            }
            if ( method_exists( $post_css, 'enqueue' ) ) {
                $post_css->enqueue();
            }
        }

        $html = $frontend->get_builder_content_for_display( $post_id, true );
        if ( ! is_string( $html ) || '' === trim( $html ) ) {
            return new WP_Error( 'figmapress_snapshot_empty', 'Elementor rendered an empty document.', array( 'status' => 500 ) );
        }
        if ( strlen( $html ) > 2500000 ) {
            return new WP_Error( 'figmapress_snapshot_too_large', 'The rendered Elementor document is too large to compare safely.', array( 'status' => 413 ) );
        }

        // Scripts are unnecessary for pixel comparison. Remove them even
        // though the browser snapshot sandbox also blocks script execution.
        $html = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $html );
        $embedded_asset_bytes = 0;
        $embedded_asset_cache = array();
        $html                 = figmapress_connector_embed_snapshot_html_images( $html, $embedded_asset_bytes, $embedded_asset_cache );
        $styles = '';
        $elementor_frontend_css = figmapress_connector_snapshot_elementor_frontend_css();
        if ( '' !== $elementor_frontend_css ) {
            $styles .= '<style data-figmapress-elementor-frontend-css>'
                . $elementor_frontend_css
                . '</style>';
        }
        $interactions_css = figmapress_connector_snapshot_interactions_css();
        if ( '' !== $interactions_css ) {
            $styles .= '<style data-figmapress-interactions-css>'
                . $interactions_css
                . '</style>';
        }

        ob_start();
        wp_print_styles();
        $printed_styles = ob_get_clean();
        if ( ! is_string( $printed_styles ) ) {
            $printed_styles = '';
        }
        if ( strlen( $printed_styles ) > 500000 ) {
            $printed_styles = substr( $printed_styles, 0, 500000 );
        }
        $styles .= $printed_styles;

        // Elementor's generated post stylesheet contains background images.
        // Inline the local file after the regular styles so those images can
        // also be embedded without cross-origin canvas tainting.
        $upload_dir    = wp_upload_dir();
        $post_css_path = trailingslashit( $upload_dir['basedir'] ) . 'elementor/css/post-' . $post_id . '.css';
        if ( is_readable( $post_css_path ) && filesize( $post_css_path ) <= 500000 ) {
            $post_css = file_get_contents( $post_css_path );
            if ( is_string( $post_css ) ) {
                $styles .= '<style data-figmapress-elementor-post-css>'
                    . figmapress_connector_embed_snapshot_css_images( $post_css, $embedded_asset_bytes, $embedded_asset_cache )
                    . '</style>';
            }
        }

        return rest_ensure_response(
            array(
                'postId'         => $post_id,
                'html'           => $html,
                'styles'         => $styles,
                'storedElements' => figmapress_connector_count_elementor_elements( figmapress_connector_read_elementor_data( $post_id ) ),
                'embeddedAssetsBytes' => $embedded_asset_bytes,
                'embeddedAssetsCount' => count( array_filter( $embedded_asset_cache, 'is_string' ) ),
                'omittedAssetsCount' => count( array_filter( $embedded_asset_cache, 'is_null' ) ),
                'webfonts'       => array_keys( figmapress_connector_page_webfonts( $post_id ) ),
                'generatedAt'    => gmdate( 'c' ),
            )
        );
    } catch ( Throwable $error ) {
        return new WP_Error(
            'figmapress_snapshot_failed',
            'Elementorの実ページ描画を取得できませんでした。',
            array( 'status' => 500 )
        );
    }
}

/**
 * Replace only a matching FigmaPress draft document. A WordPress revision is
 * created first and the caller can send the baseline template again to roll
 * back a correction that did not improve the measured output.
 */
function figmapress_connector_rest_update_elementor_document( WP_REST_Request $request ) {
    $post_id = figmapress_connector_validate_owned_elementor_draft( $request );
    if ( is_wp_error( $post_id ) ) {
        return $post_id;
    }

    $params   = $request->get_json_params();
    $template = isset( $params['template'] ) && is_array( $params['template'] ) ? $params['template'] : null;
    if ( ! $template || '0.4' !== ( isset( $template['version'] ) ? (string) $template['version'] : '' ) ) {
        return new WP_Error( 'figmapress_invalid_template', 'The Elementor template payload is invalid.', array( 'status' => 422 ) );
    }

    $element_count = 0;
    $content       = figmapress_connector_sanitize_elementor_elements(
        isset( $template['content'] ) ? $template['content'] : array(),
        $element_count
    );
    if ( is_wp_error( $content ) ) {
        return $content;
    }
    if ( 0 === $element_count ) {
        return new WP_Error( 'figmapress_empty_template', 'The Elementor template contains no supported elements.', array( 'status' => 422 ) );
    }

    $page_settings = isset( $template['page_settings'] ) && is_array( $template['page_settings'] )
        ? figmapress_connector_sanitize_elementor_value( $template['page_settings'] )
        : array();
    $page_template = isset( $params['pageTemplate'] ) ? $params['pageTemplate'] : 'elementor_canvas';
    if ( ! in_array( $page_template, array( 'elementor_canvas', 'elementor_header_footer', 'default' ), true ) ) {
        $page_template = 'elementor_canvas';
    }

    // Visual QA sends the corrected source template again. Reapply every
    // previously imported image before saving so a correction can never roll
    // Media Library URLs back to expiring Figma URLs.
    $media_total = figmapress_connector_count_unique_elementor_images( $content );
    update_post_meta( $post_id, '_figmapress_media_total', $media_total );
    $localized_images = figmapress_connector_load_media_map( $post_id );
    figmapress_connector_apply_elementor_image_map( $content, $localized_images );

    $revision_id = wp_save_post_revision( $post_id );
    $stored      = figmapress_connector_store_elementor_document( $post_id, $content, $page_settings, $page_template );
    if ( is_wp_error( $stored ) ) {
        return $stored;
    }
    update_post_meta( $post_id, '_figmapress_last_visual_update', time() );
    figmapress_connector_clear_elementor_cache( $post_id );

    return rest_ensure_response(
        array(
            'postId'         => $post_id,
            'status'         => 'draft',
            'storedElements' => $stored,
            'revisionId'     => is_numeric( $revision_id ) ? absint( $revision_id ) : null,
        )
    );
}

function figmapress_connector_ensure_elementor_containers() {
    if ( ! class_exists( '\\Elementor\\Plugin' ) || ! isset( \Elementor\Plugin::$instance->elements_manager ) ) {
        return new WP_Error(
            'figmapress_elementor_container_unavailable',
            'Elementor Containers are not available on this site.',
            array( 'status' => 409 )
        );
    }

    $elements_manager = \Elementor\Plugin::$instance->elements_manager;
    if ( method_exists( $elements_manager, 'get_element_types' ) ) {
        $container = $elements_manager->get_element_types( 'container' );
        if ( $container ) {
            return false;
        }
    }

    if ( ! current_user_can( 'manage_options' ) ) {
        return new WP_Error(
            'figmapress_elementor_container_inactive',
            'Elementor Containers are disabled. Ask a WordPress administrator to enable Elementor > Settings > Features > Container.',
            array( 'status' => 409 )
        );
    }

    if ( ! isset( \Elementor\Plugin::$instance->experiments ) ) {
        return new WP_Error(
            'figmapress_elementor_container_unavailable',
            'Elementor Containers are not available on this site.',
            array( 'status' => 409 )
        );
    }

    $experiments = \Elementor\Plugin::$instance->experiments;
    $feature     = method_exists( $experiments, 'get_features' )
        ? $experiments->get_features( 'container' )
        : null;
    if ( ! $feature ) {
        return new WP_Error(
            'figmapress_elementor_container_unavailable',
            'This Elementor version does not provide the Container feature required by the generated page.',
            array( 'status' => 409 )
        );
    }

    $option_key = method_exists( $experiments, 'get_feature_option_key' )
        ? $experiments->get_feature_option_key( 'container' )
        : 'elementor_experiment-container';
    update_option( $option_key, 'active' );

    if ( 'active' !== get_option( $option_key ) ) {
        return new WP_Error(
            'figmapress_elementor_container_activation_failed',
            'Elementor Containers could not be enabled on this site.',
            array( 'status' => 500 )
        );
    }

    return true;
}

function figmapress_connector_store_elementor_document( $post_id, $content, $page_settings, $page_template ) {
    $expected_elements = figmapress_connector_count_elementor_elements( $content );
    $encoded_content   = wp_json_encode( $content );
    if ( false === $encoded_content ) {
        return new WP_Error(
            'figmapress_elementor_encode_failed',
            'Elementor data could not be encoded for storage.',
            array(
                'status'           => 500,
                'expectedElements' => $expected_elements,
            )
        );
    }
    $encoded_bytes = strlen( $encoded_content );

    // Store the complete editable document before calling Elementor's
    // Document API. On shared hosts a multi-megabyte absolute-positioned page
    // can spend the whole PHP request inside Document::save(), leaving an empty
    // draft and a stale request lock. Elementor reads these same metadata keys,
    // so this direct write is both a durable checkpoint and the fast path for
    // large documents.
    $direct_meta_write = update_metadata(
        'post',
        $post_id,
        '_elementor_data',
        wp_slash( $encoded_content )
    );
    update_post_meta( $post_id, '_elementor_edit_mode', 'builder' );
    update_post_meta( $post_id, '_elementor_template_type', 'wp-page' );
    update_post_meta( $post_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '' );
    update_post_meta( $post_id, '_elementor_page_settings', $page_settings );
    update_post_meta( $post_id, '_wp_page_template', $page_template );

    $saved_with_document_api = false;
    $document_api_skipped    = $expected_elements > 350 || $encoded_bytes > 600000;
    if (
        ! $document_api_skipped &&
        class_exists( '\\Elementor\\Plugin' ) &&
        isset( \Elementor\Plugin::$instance->documents )
    ) {
        try {
            $document = \Elementor\Plugin::$instance->documents->get( $post_id );
            if ( $document && method_exists( $document, 'save' ) ) {
                $saved_with_document_api = true === $document->save(
                    array(
                        'elements' => $content,
                        'settings' => $page_settings,
                    )
                );
            }
        } catch ( Throwable $error ) {
            $saved_with_document_api = false;
        }

        // Elementor may normalize the document while dropping FigmaPress QA
        // metadata. Restore the already-sanitized source after its bookkeeping.
        $direct_meta_write = update_metadata(
            'post',
            $post_id,
            '_elementor_data',
            wp_slash( $encoded_content )
        );
        update_post_meta( $post_id, '_elementor_page_settings', $page_settings );
        update_post_meta( $post_id, '_wp_page_template', $page_template );
    }

    // Persistent object caches can briefly retain an older value. Force the
    // verification read back to the database after the final metadata write.
    wp_cache_delete( $post_id, 'post_meta' );
    $stored_data     = figmapress_connector_read_elementor_data( $post_id );
    $stored_elements = is_array( $stored_data )
        ? figmapress_connector_count_elementor_elements( $stored_data )
        : 0;

    if ( ! is_array( $stored_data ) || $stored_elements !== $expected_elements ) {
        return new WP_Error(
            'figmapress_elementor_save_failed',
            'Elementor data could not be stored on this server.',
            array(
                'status'                => 500,
                'expectedElements'      => $expected_elements,
                'storedElements'        => $stored_elements,
                'documentSaveCompleted' => $saved_with_document_api,
                'documentApiSkipped'    => $document_api_skipped,
                'directMetaWrite'       => false !== $direct_meta_write,
                'encodedBytes'          => $encoded_bytes,
            )
        );
    }

    return $stored_elements;
}

function figmapress_connector_read_elementor_data( $post_id ) {
    $stored_value = get_metadata( 'post', $post_id, '_elementor_data', true );
    if ( is_array( $stored_value ) ) {
        return $stored_value;
    }
    if ( ! is_string( $stored_value ) || '' === trim( $stored_value ) ) {
        return null;
    }

    $decoded = json_decode( $stored_value, true );
    return is_array( $decoded ) ? $decoded : null;
}

function figmapress_connector_count_elementor_elements( $elements ) {
    $count = 0;
    foreach ( $elements as $element ) {
        if ( ! is_array( $element ) ) {
            continue;
        }
        ++$count;
        if ( isset( $element['elements'] ) && is_array( $element['elements'] ) ) {
            $count += figmapress_connector_count_elementor_elements( $element['elements'] );
        }
    }
    return $count;
}

function figmapress_connector_sanitize_elementor_elements( $elements, &$count ) {
    if ( ! is_array( $elements ) ) {
        return new WP_Error( 'figmapress_invalid_elements', 'Elementor content must be an array.', array( 'status' => 422 ) );
    }

    $result          = array();
    $allowed_widgets = array(
        'heading',
        'text-editor',
        'button',
        'image',
        'figmapress-nav',
        'figmapress-link',
        'figmapress-carousel',
        'figmapress-contact-form',
        'figmapress-accordion',
    );
    foreach ( $elements as $element ) {
        if ( ! is_array( $element ) || $count >= 1200 ) {
            continue;
        }
        $el_type = isset( $element['elType'] ) ? $element['elType'] : '';
        if ( 'container' !== $el_type && 'widget' !== $el_type ) {
            continue;
        }
        $widget_type = isset( $element['widgetType'] ) ? sanitize_key( $element['widgetType'] ) : '';
        if ( 'widget' === $el_type && ! in_array( $widget_type, $allowed_widgets, true ) ) {
            continue;
        }

        ++$count;
        $children = figmapress_connector_sanitize_elementor_elements(
            isset( $element['elements'] ) ? $element['elements'] : array(),
            $count
        );
        if ( is_wp_error( $children ) ) {
            return $children;
        }

        $clean = array(
            'id'       => preg_replace( '/[^a-f0-9]/', '', strtolower( isset( $element['id'] ) ? $element['id'] : '' ) ),
            'elType'   => $el_type,
            'isInner'  => ! empty( $element['isInner'] ),
            'settings' => figmapress_connector_sanitize_elementor_value( isset( $element['settings'] ) ? $element['settings'] : array() ),
            'elements' => $children,
        );
        if ( strlen( $clean['id'] ) < 6 ) {
            $clean['id'] = substr( md5( wp_generate_uuid4() ), 0, 8 );
        }
        if ( 'widget' === $el_type ) {
            $clean['widgetType'] = $widget_type;
        }
        $result[] = $clean;
    }
    return $result;
}

function figmapress_connector_sanitize_elementor_value( $value, $key = '', $depth = 0 ) {
    if ( $depth > 24 ) {
        return null;
    }
    if ( is_array( $value ) ) {
        $clean = array();
        foreach ( $value as $child_key => $child_value ) {
            // Elementor uses case-sensitive setting keys such as `isLinked`.
            // Keep their casing while still rejecting unexpected characters.
            $safe_key = is_int( $child_key )
                ? $child_key
                : preg_replace( '/[^A-Za-z0-9_-]/', '', (string) $child_key );
            if ( '' === $safe_key || null === $safe_key ) {
                continue;
            }
            $clean[ $safe_key ] = figmapress_connector_sanitize_elementor_value( $child_value, (string) $safe_key, $depth + 1 );
        }
        return $clean;
    }
    if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) || null === $value ) {
        return $value;
    }
    if ( ! is_string( $value ) ) {
        return '';
    }
    if ( 'editor' === $key ) {
        add_filter( 'safe_style_css', 'figmapress_connector_allow_layout_css' );
        try {
            return wp_kses_post( $value );
        } finally {
            remove_filter( 'safe_style_css', 'figmapress_connector_allow_layout_css' );
        }
    }
    if ( 'url' === $key ) {
        return esc_url_raw( $value, array( 'http', 'https', 'mailto', 'tel' ) );
    }
    return sanitize_text_field( $value );
}

function figmapress_connector_allow_layout_css( $properties ) {
    return array_values(
        array_unique(
            array_merge(
                $properties,
                array(
                    'display',
                    'flex-direction',
                    'justify-content',
                    'min-height',
                    'overflow',
                    'overflow-wrap',
                    'white-space',
                    'word-break',
                )
            )
        )
    );
}

function figmapress_connector_image_setting_url( $image ) {
    return is_array( $image ) && isset( $image['url'] ) && is_string( $image['url'] )
        ? trim( $image['url'] )
        : '';
}

function figmapress_connector_image_setting_key( $image ) {
    if ( ! is_array( $image ) || empty( $image['figmapress_key'] ) || ! is_string( $image['figmapress_key'] ) ) {
        return '';
    }
    $key = preg_replace( '/[^A-Za-z0-9:_-]/', '', $image['figmapress_key'] );
    return is_string( $key ) ? substr( $key, 0, 190 ) : '';
}

function figmapress_connector_collect_elementor_image_urls( $elements, &$urls, $remote_only = false ) {
    foreach ( $elements as $element ) {
        if ( ! is_array( $element ) ) {
            continue;
        }
        $settings    = isset( $element['settings'] ) && is_array( $element['settings'] ) ? $element['settings'] : array();
        $image_slots = array();
        if ( 'widget' === ( isset( $element['elType'] ) ? $element['elType'] : '' ) ) {
            $widget_type = isset( $element['widgetType'] ) ? $element['widgetType'] : '';
            if ( 'image' === $widget_type && isset( $settings['image'] ) ) {
                $image_slots[] = $settings['image'];
            }
            if ( 'figmapress-nav' === $widget_type ) {
                foreach ( array( 'logo', 'cta_icon' ) as $nav_image_key ) {
                    if ( isset( $settings[ $nav_image_key ] ) ) {
                        $image_slots[] = $settings[ $nav_image_key ];
                    }
                }
            }
            if ( 'figmapress-carousel' === $widget_type ) {
                if ( isset( $settings['items'] ) && is_array( $settings['items'] ) ) {
                    foreach ( $settings['items'] as $item ) {
                        if ( is_array( $item ) && isset( $item['image'] ) ) {
                            $image_slots[] = $item['image'];
                        }
                    }
                }
                foreach ( array( 'previous_icon', 'next_icon' ) as $icon_key ) {
                    if ( isset( $settings[ $icon_key ] ) ) {
                        $image_slots[] = $settings[ $icon_key ];
                    }
                }
            }
        }
        if ( 'container' === ( isset( $element['elType'] ) ? $element['elType'] : '' ) && isset( $settings['background_image'] ) ) {
            $image_slots[] = $settings['background_image'];
        }
        foreach ( $image_slots as $image ) {
            $url = figmapress_connector_image_setting_url( $image );
            if ( '' === $url ) {
                continue;
            }
            if (
                $remote_only
                && is_array( $image )
                && 'library' === ( isset( $image['source'] ) ? $image['source'] : '' )
                && ! empty( $image['id'] )
            ) {
                continue;
            }
            $urls[ hash( 'sha256', $url ) ] = $url;
        }
        if ( isset( $element['elements'] ) && is_array( $element['elements'] ) ) {
            figmapress_connector_collect_elementor_image_urls( $element['elements'], $urls, $remote_only );
        }
    }
}

function figmapress_connector_count_unique_elementor_images( $elements ) {
    $urls = array();
    figmapress_connector_collect_elementor_image_urls( $elements, $urls, false );
    return count( $urls );
}

function figmapress_connector_load_media_map( $post_id ) {
    $stored = get_post_meta( $post_id, '_figmapress_media_map', true );
    $map    = array();
    if ( ! is_array( $stored ) ) {
        return $map;
    }
    foreach ( array_slice( $stored, 0, 300, true ) as $entry ) {
        if ( ! is_array( $entry ) ) {
            continue;
        }
        $source_url    = isset( $entry['sourceUrl'] ) ? esc_url_raw( $entry['sourceUrl'], array( 'https' ) ) : '';
        $attachment_id = isset( $entry['id'] ) ? absint( $entry['id'] ) : 0;
        $local_url     = $attachment_id ? wp_get_attachment_url( $attachment_id ) : false;
        if ( '' === $source_url || ! $local_url ) {
            continue;
        }
        $map[ $source_url ] = array(
            'id'     => $attachment_id,
            'url'    => $local_url,
            'source' => 'library',
            'sourceUrl' => $source_url,
            'stableKey' => isset( $entry['stableKey'] ) ? figmapress_connector_image_setting_key( array( 'figmapress_key' => $entry['stableKey'] ) ) : '',
        );
        if ( '' !== $map[ $source_url ]['stableKey'] ) {
            $map[ 'key:' . $map[ $source_url ]['stableKey'] ] = $map[ $source_url ];
        }
    }
    return $map;
}

function figmapress_connector_save_media_map( $post_id, $map ) {
    $stored = array();
    foreach ( $map as $entry ) {
        if ( count( $stored ) >= 300 || ! is_array( $entry ) ) {
            continue;
        }
        $source_url = isset( $entry['sourceUrl'] ) ? $entry['sourceUrl'] : '';
        $stable_key = isset( $entry['stableKey'] ) ? $entry['stableKey'] : '';
        $attachment_id = isset( $entry['id'] ) ? absint( $entry['id'] ) : 0;
        if ( 0 !== strpos( $source_url, 'https://' ) || ! $attachment_id || ! wp_get_attachment_url( $attachment_id ) ) {
            continue;
        }
        $record_key = '' !== $stable_key ? 'key:' . $stable_key : 'url:' . hash( 'sha256', $source_url );
        $stored[ hash( 'sha256', $record_key ) ] = array(
            'sourceUrl' => $source_url,
            'stableKey' => $stable_key,
            'id'        => $attachment_id,
        );
    }
    update_post_meta( $post_id, '_figmapress_media_map', $stored );
}

function figmapress_connector_load_media_failures( $post_id ) {
    $stored = get_post_meta( $post_id, '_figmapress_media_failures', true );
    return is_array( $stored ) ? array_slice( $stored, 0, 300, true ) : array();
}

function figmapress_connector_save_media_failures( $post_id, $failures ) {
    $clean = array();
    foreach ( array_slice( $failures, 0, 300, true ) as $url_hash => $attempts ) {
        if ( preg_match( '/^[a-f0-9]{64}$/', (string) $url_hash ) ) {
            $clean[ $url_hash ] = min( 3, absint( $attempts ) );
        }
    }
    if ( $clean ) {
        update_post_meta( $post_id, '_figmapress_media_failures', $clean );
    } else {
        delete_post_meta( $post_id, '_figmapress_media_failures' );
    }
}

function figmapress_connector_apply_image_map_setting( &$image, $localized_images ) {
    $url = figmapress_connector_image_setting_url( $image );
    $stable_key = figmapress_connector_image_setting_key( $image );
    $match = '' !== $stable_key && isset( $localized_images[ 'key:' . $stable_key ] )
        ? $localized_images[ 'key:' . $stable_key ]
        : ( '' !== $url && isset( $localized_images[ $url ] ) ? $localized_images[ $url ] : null );
    if ( is_array( $match ) ) {
        $image = array_merge(
            $image,
            array(
                'id'     => isset( $match['id'] ) ? $match['id'] : '',
                'url'    => isset( $match['url'] ) ? $match['url'] : $url,
                'source' => 'library',
            )
        );
    }
}

function figmapress_connector_apply_elementor_image_map( &$elements, $localized_images ) {
    foreach ( $elements as &$element ) {
        if ( ! is_array( $element ) ) {
            continue;
        }
        if ( 'widget' === ( isset( $element['elType'] ) ? $element['elType'] : '' ) && 'image' === ( isset( $element['widgetType'] ) ? $element['widgetType'] : '' ) && isset( $element['settings']['image'] ) ) {
            figmapress_connector_apply_image_map_setting( $element['settings']['image'], $localized_images );
        }
        if ( 'widget' === ( isset( $element['elType'] ) ? $element['elType'] : '' ) && 'figmapress-nav' === ( isset( $element['widgetType'] ) ? $element['widgetType'] : '' ) ) {
            foreach ( array( 'logo', 'cta_icon' ) as $nav_image_key ) {
                if ( isset( $element['settings'][ $nav_image_key ] ) ) {
                    figmapress_connector_apply_image_map_setting( $element['settings'][ $nav_image_key ], $localized_images );
                }
            }
        }
        if ( 'widget' === ( isset( $element['elType'] ) ? $element['elType'] : '' ) && 'figmapress-carousel' === ( isset( $element['widgetType'] ) ? $element['widgetType'] : '' ) ) {
            if ( isset( $element['settings']['items'] ) && is_array( $element['settings']['items'] ) ) {
                foreach ( $element['settings']['items'] as &$carousel_item ) {
                    if ( isset( $carousel_item['image'] ) ) {
                        figmapress_connector_apply_image_map_setting( $carousel_item['image'], $localized_images );
                    }
                }
                unset( $carousel_item );
            }
            foreach ( array( 'previous_icon', 'next_icon' ) as $icon_key ) {
                if ( isset( $element['settings'][ $icon_key ] ) ) {
                    figmapress_connector_apply_image_map_setting( $element['settings'][ $icon_key ], $localized_images );
                }
            }
        }
        if ( 'container' === ( isset( $element['elType'] ) ? $element['elType'] : '' ) && isset( $element['settings']['background_image'] ) ) {
            figmapress_connector_apply_image_map_setting( $element['settings']['background_image'], $localized_images );
        }
        if ( ! empty( $element['elements'] ) ) {
            figmapress_connector_apply_elementor_image_map( $element['elements'], $localized_images );
        }
    }
    unset( $element );
}

function figmapress_connector_elementor_media_progress( $elements, $post_id ) {
    $pending_urls = array();
    figmapress_connector_collect_elementor_image_urls( $elements, $pending_urls, true );
    $failures = figmapress_connector_load_media_failures( $post_id );
    $failed   = 0;
    foreach ( $pending_urls as $url_hash => $url ) {
        if ( isset( $failures[ $url_hash ] ) && absint( $failures[ $url_hash ] ) >= 3 ) {
            ++$failed;
        }
    }
    $pending_total = count( $pending_urls );
    $remaining     = max( 0, $pending_total - $failed );
    $total         = absint( get_post_meta( $post_id, '_figmapress_media_total', true ) );
    if ( $total < $pending_total ) {
        $total = $pending_total;
    }
    return array(
        'savedMedia'     => max( 0, $total - $pending_total ),
        'totalMedia'     => $total,
        'remainingMedia' => $remaining,
        'failedMedia'    => $failed,
        'mediaComplete'  => 0 === $remaining && 0 === $failed,
    );
}

function figmapress_connector_localize_elementor_images( &$elements, $post_id, &$warnings, &$imported_media, $deadline, &$localized_images, &$media_failures ) {
    foreach ( $elements as &$element ) {
        if ( microtime( true ) >= $deadline ) {
            figmapress_connector_add_media_budget_warning( $warnings );
            return;
        }
        if ( 'widget' === $element['elType'] && 'image' === ( isset( $element['widgetType'] ) ? $element['widgetType'] : '' ) && isset( $element['settings']['image'] ) ) {
            figmapress_connector_localize_image_setting( $element['settings']['image'], $post_id, $warnings, $imported_media, $deadline, $localized_images, $media_failures );
        }
        if ( 'widget' === $element['elType'] && 'figmapress-nav' === ( isset( $element['widgetType'] ) ? $element['widgetType'] : '' ) ) {
            foreach ( array( 'logo', 'cta_icon' ) as $nav_image_key ) {
                if ( isset( $element['settings'][ $nav_image_key ] ) ) {
                    figmapress_connector_localize_image_setting( $element['settings'][ $nav_image_key ], $post_id, $warnings, $imported_media, $deadline, $localized_images, $media_failures );
                }
            }
        }
        if ( 'widget' === $element['elType'] && 'figmapress-carousel' === ( isset( $element['widgetType'] ) ? $element['widgetType'] : '' ) ) {
            if ( isset( $element['settings']['items'] ) && is_array( $element['settings']['items'] ) ) {
                foreach ( $element['settings']['items'] as &$carousel_item ) {
                    if ( isset( $carousel_item['image'] ) ) {
                        figmapress_connector_localize_image_setting( $carousel_item['image'], $post_id, $warnings, $imported_media, $deadline, $localized_images, $media_failures );
                    }
                }
                unset( $carousel_item );
            }
            foreach ( array( 'previous_icon', 'next_icon' ) as $icon_key ) {
                if ( isset( $element['settings'][ $icon_key ] ) ) {
                    figmapress_connector_localize_image_setting( $element['settings'][ $icon_key ], $post_id, $warnings, $imported_media, $deadline, $localized_images, $media_failures );
                }
            }
        }
        if ( 'container' === $element['elType'] && isset( $element['settings']['background_image'] ) ) {
            figmapress_connector_localize_image_setting( $element['settings']['background_image'], $post_id, $warnings, $imported_media, $deadline, $localized_images, $media_failures );
        }
        if ( ! empty( $element['elements'] ) ) {
            figmapress_connector_localize_elementor_images( $element['elements'], $post_id, $warnings, $imported_media, $deadline, $localized_images, $media_failures );
        }
    }
}

function figmapress_connector_add_media_budget_warning( &$warnings ) {
    $message = '画像の保存は時間上限に達したため一部を元URLのまま保持しました。';
    if ( ! in_array( $message, $warnings, true ) ) {
        $warnings[] = $message;
    }
}

function figmapress_connector_localize_image_setting( &$image, $post_id, &$warnings, &$imported_media, $deadline, &$localized_images, &$media_failures ) {
    if ( ! is_array( $image ) ) {
        return;
    }
    if ( 'library' === ( isset( $image['source'] ) ? $image['source'] : '' ) && ! empty( $image['id'] ) ) {
        return;
    }
    $url = isset( $image['url'] ) ? $image['url'] : '';
    if ( ! $url ) {
        return;
    }
    $stable_key = figmapress_connector_image_setting_key( $image );
    if ( isset( $localized_images[ $url ] ) ) {
        if ( '' !== $stable_key ) {
            $stable_entry              = $localized_images[ $url ];
            $stable_entry['stableKey'] = $stable_key;
            $localized_images[ 'key:' . $stable_key ] = $stable_entry;
        }
        figmapress_connector_apply_image_map_setting( $image, $localized_images );
        return;
    }
    if ( '' !== $stable_key && isset( $localized_images[ 'key:' . $stable_key ] ) ) {
        figmapress_connector_apply_image_map_setting( $image, $localized_images );
        return;
    }
    $url_hash = hash( 'sha256', $url );
    if ( isset( $media_failures[ $url_hash ] ) && absint( $media_failures[ $url_hash ] ) >= 3 ) {
        return;
    }
    if ( $imported_media >= 10 ) {
        return;
    }
    $remaining = (int) floor( $deadline - microtime( true ) );
    if ( $remaining < 1 ) {
        figmapress_connector_add_media_budget_warning( $warnings );
        return;
    }
    $attachment = figmapress_connector_sideload_image(
        $url,
        $post_id,
        isset( $image['alt'] ) ? $image['alt'] : '',
        min( 15, $remaining )
    );
    if ( is_wp_error( $attachment ) ) {
        $media_failures[ $url_hash ] = min( 3, ( isset( $media_failures[ $url_hash ] ) ? absint( $media_failures[ $url_hash ] ) : 0 ) + 1 );
        $warnings[] = '画像をメディアライブラリへ保存できませんでした: ' . $attachment->get_error_message();
        return;
    }
    $image['id']     = $attachment['id'];
    $image['url']    = $attachment['url'];
    $image['source'] = 'library';
    $localized_entry = array(
        'id'     => $image['id'],
        'url'    => $image['url'],
        'source' => $image['source'],
        'sourceUrl' => $url,
        'stableKey' => $stable_key,
    );
    $localized_images[ $url ] = $localized_entry;
    if ( '' !== $stable_key ) {
        $localized_images[ 'key:' . $stable_key ] = $localized_entry;
    }
    unset( $media_failures[ $url_hash ] );
    ++$imported_media;
}

function figmapress_connector_sideload_image( $url, $post_id, $alt, $download_timeout = 6 ) {
    if ( 0 !== strpos( $url, 'https://' ) || ! wp_http_validate_url( $url ) ) {
        return new WP_Error( 'figmapress_invalid_image_url', 'The image URL is not a public HTTPS URL.' );
    }
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';

    $tmp = download_url( $url, max( 1, (int) $download_timeout ) );
    if ( is_wp_error( $tmp ) ) {
        return $tmp;
    }
    if ( filesize( $tmp ) > 10 * MB_IN_BYTES ) {
        @unlink( $tmp );
        return new WP_Error( 'figmapress_image_too_large', 'The image exceeds 10 MB.' );
    }

    $mime = wp_get_image_mime( $tmp );
    $exts = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp', 'image/avif' => 'avif' );
    if ( ! isset( $exts[ $mime ] ) ) {
        @unlink( $tmp );
        return new WP_Error( 'figmapress_invalid_image', 'The downloaded file is not a supported image.' );
    }

    $file_array = array(
        'name'     => 'figmapress-' . substr( md5( $url ), 0, 12 ) . '.' . $exts[ $mime ],
        'tmp_name' => $tmp,
    );
    $attachment_id = media_handle_sideload( $file_array, $post_id, sanitize_text_field( $alt ) );
    if ( is_wp_error( $attachment_id ) ) {
        @unlink( $tmp );
        return $attachment_id;
    }
    update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( $alt ) );
    return array( 'id' => $attachment_id, 'url' => wp_get_attachment_url( $attachment_id ) );
}

function figmapress_connector_clear_elementor_cache( $post_id ) {
    try {
        if ( class_exists( '\\Elementor\\Core\\Files\\CSS\\Post' ) ) {
            $css_file = new \Elementor\Core\Files\CSS\Post( $post_id );
            $css_file->delete();
        }
        if ( isset( \Elementor\Plugin::$instance->files_manager ) ) {
            \Elementor\Plugin::$instance->files_manager->clear_cache();
        }
    } catch ( Throwable $error ) {
        // Elementor regenerates CSS on the next editor/frontend request.
    }
}
